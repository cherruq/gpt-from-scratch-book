# M4-v2

python -m pip install -r requirements.txt

复现命令：python -m examples.attention_labs 25
