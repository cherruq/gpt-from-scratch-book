# M4-v1

python -m pip install -r requirements.txt

复现命令：python -m examples.transformer 23
