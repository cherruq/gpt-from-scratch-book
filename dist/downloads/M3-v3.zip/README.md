# M3-v3

python -m pip install -r requirements.txt

复现命令：python -m examples.language_pipeline
