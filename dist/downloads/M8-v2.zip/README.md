# M8-v2

python -m pip install -r requirements.txt
PyTorch 查验需要另装 CPU 版 torch==2.10.0+cpu。

复现命令：python -m examples.training_labs 30
