# M6-v1

python -m pip install -r requirements.txt

复现命令：python -m src.numpy_gpt.train fit --steps 1
